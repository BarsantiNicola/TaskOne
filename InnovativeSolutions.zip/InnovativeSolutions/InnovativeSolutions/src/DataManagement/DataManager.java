package DataManagement;

import beans.Employee;
import beans.Product;
import beans.User;

import java.util.List;

public class DataManager {

    public List<User> searchUsers(String SEARCHED_STRING ){ return null; }

    public List<User> getUsers(){ return null; }

    public boolean insertUser( User NEW_USER ){ return false; }

    public boolean updateSalary(int SALARY , String USER_ID  ){ return false; }

    public boolean deleteUser( String USER_NAME ){ return false; }

    public List<Product> getAvailableProducts(){ return null; }

    public List<Product> searchProducts( String SEARCHED_STRING ){ return null; }

    public int getProductType( String PRODUCT_NAME ){ return 0; }

    public int getTeam( String USERNAME ){ return 0; }

    public UserType login( String USERNAME , String PASSWORD ){ return null; }

    public int getMinIDProduct( int PRODUCT_TYPE ){ return 0; }

    public boolean insertOrder( String CUSTOMER_ID , int PRODUCT_ID , int PRICE ){ return false; }

    public List<Product> getTeamProducts( int TEAM_ID ){ return null; }

    public List<Employee> getTeamEmployees(int TEAM_ID ){ return null; }

    public boolean updateProductAvailability( int PRODUCT_TYPE , int ADDED_AVAILABILITY ){ return false; }

    public List<Employee> searchTeamEmployees( int TEAM_ID , String SEARCHED_VALUE ){ return null; }

    public List<Product> searchTeamProducts( int TEAM_ID , String SEARCHED_VALUE ){ return null; }
}
