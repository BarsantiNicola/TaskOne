package DataManagement;

public class DataRequest{

    private enum USERS{ GETLIST , SEARCH , INSERT , UPDATE , DELETE }
    private enum EMPLOYEES{ GETLIST , SEARCH , UPDATE }
    private enum PRODUCTS{ GETLIST , SEARCH , UPDATE }
    private enum ORDERS{ GETLIST , SEARCH , INSERT }

    public USERS USERS;
    public EMPLOYEES EMPLOYEES;
    public PRODUCTS PRODUCTS;
    public ORDERS ORDERS;

}
