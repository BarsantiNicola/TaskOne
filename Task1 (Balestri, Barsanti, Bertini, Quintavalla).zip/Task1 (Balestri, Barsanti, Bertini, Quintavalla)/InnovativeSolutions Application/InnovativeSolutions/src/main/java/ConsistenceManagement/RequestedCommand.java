package ConsistenceManagement;

public enum RequestedCommand{
	
	ADDORDER,
	ADDHORDER,
	ADDPRODUCT,
	ADDCUSTOMER,
	REMOVECUSTOMER,

}
