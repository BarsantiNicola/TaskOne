package DataManagement;

public enum UserType{
    ADMINISTRATOR,
    TEAMLEADER,
    CUSTOMER,
    NOUSER
};